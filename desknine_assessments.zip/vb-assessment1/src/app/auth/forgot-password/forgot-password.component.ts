import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EMAIL_REGEX_PATTERN } from 'src/app/shared/constants';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
})
export class ForgotPasswordComponent implements OnInit {
  formGroup!: FormGroup;
  isSubmitted: boolean = false;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.setupResetPasswordForm();
  }

  setupResetPasswordForm(): void {
    this.formGroup = new FormGroup({
      email: new FormControl('', [
        Validators.required,
        Validators.pattern(EMAIL_REGEX_PATTERN),
      ]),
    });
  }

  resetPassword({ valid, value }: FormGroup): void {
    if (valid) {
      // 15 digit random password for the given email ID
      const newPassword = Math.floor(
        100000000000000 + Math.random() * 900000000
      ).toString();
      alert(`Password reset successfully to ${newPassword}.`);
      this.formGroup.reset();
      this.router.navigate(['auth/login']);
    }
  }

  getControl(controlName: string): FormControl {
    return this.formGroup.get(controlName) as FormControl;
  }

  isRequired(controlName: string): boolean {
    return (
      (this.getControl(controlName).touched || this.isSubmitted) &&
      (this.getControl(controlName)?.errors?.required ||
        !this.getControl(controlName).value?.toString().trim())
    );
  }

  isInvalid(controlName: string): boolean {
    return this.getControl(controlName)?.errors?.pattern;
  }
}
