import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EMAIL_REGEX_PATTERN } from 'src/app/shared/constants';
import { confirmPasswordValidator } from 'src/app/shared/custom-validators';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss'],
})
export class SignupComponent implements OnInit {
  formGroup!: FormGroup;
  isSubmitted: boolean = false;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.setupSignUpForm();
  }

  setupSignUpForm(): void {
    this.formGroup = new FormGroup(
      {
        name: new FormControl('', Validators.required),
        email: new FormControl('', [
          Validators.required,
          Validators.pattern(EMAIL_REGEX_PATTERN),
        ]),
        phoneNumber: new FormControl('', Validators.required),
        password: new FormControl('', Validators.required),
        confirmPassword: new FormControl('', Validators.required),
      },
      confirmPasswordValidator('password', 'confirmPassword')
    );
  }

  onSubmit({ valid, value }: FormGroup): void {
    this.isSubmitted = true;
    if (valid) {
      this.router.navigate(['auth/login']);
    }
  }

  getControl(controlName: string): FormControl {
    return this.formGroup.get(controlName) as FormControl;
  }

  isRequired(controlName: string): boolean {
    return (
      (this.getControl(controlName).touched || this.isSubmitted) &&
      (this.getControl(controlName)?.errors?.required ||
        !this.getControl(controlName).value?.toString().trim())
    );
  }

  isInvalid(controlName: string): boolean {
    return this.getControl(controlName)?.errors?.pattern;
  }

  isMatched(controlName: string): boolean {
    return this.getControl(controlName)?.value && this.formGroup.errors?.noMatch;
  }
}
