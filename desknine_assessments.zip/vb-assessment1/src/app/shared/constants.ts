export const EMAIL_REGEX_PATTERN =
  '^[\\w\\.-]+@[a-zA-Z\\d\\.-]+\\.[a-zA-Z]{2,}$';
