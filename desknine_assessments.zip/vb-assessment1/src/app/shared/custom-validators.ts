import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export function confirmPasswordValidator(
  pass: string,
  confirmPass: string
): ValidatorFn {
  return (form: AbstractControl): ValidationErrors | null => {
    return form.get(pass.toString())?.value.toString() !==
      form.get(confirmPass.toString())?.value
      ? { noMatch: true }
      : null;
  };
}
