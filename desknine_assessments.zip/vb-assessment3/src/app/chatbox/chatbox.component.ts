import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ChatService } from '../shared/chat.service';
import { IMessage } from '../shared/typings';

@Component({
  selector: 'app-chatbox',
  templateUrl: './chatbox.component.html',
  styleUrls: ['./chatbox.component.scss'],
})
export class ChatboxComponent implements OnInit {
  message: string = '';
  messageList: IMessage[] = [];
  currentUser: { userId: number; userName: string } = {
    userId: 88,
    userName: 'Vaishnavi Bunde',
  };
  colorList: string[] = ['olivedrab', 'purple', 'orangered', 'palevioletred'];

  constructor(
    private chatService: ChatService,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.messageList = this.chatService.getMessages();
  }

  onSend(): void {
    if (!!this.message.trim()) {
      this.chatService.sendMessage({
        message: this.message,
        senderId: this.currentUser.userId,
        senderName: this.currentUser.userName,
        dateTime: new Date().toString(),
      });

      this.message = '';
    }
  }

  getBackgroundColor(message: IMessage, index: number): string {
    return message.senderId === this.currentUser.userId
      ? 'tomato'
      : this.colorList[Math.round(index / this.colorList.length)];
  }
}
