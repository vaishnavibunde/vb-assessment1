export interface IMessage {
  senderId: number;
  senderName: string;
  message: string;
  dateTime: string;
}

export const DUMMY_CHAT_DATA: IMessage[] = [
  {
    senderId: 1,
    senderName: 'Naresh Kumar',
    message: 'Hello',
    dateTime: new Date().toString(),
  },
  {
    senderId: 1,
    senderName: 'Naresh Kumar',
    message: 'Hello',
    dateTime: new Date().toString(),
  },
  {
    senderId: 2,
    senderName: 'Mahesh Jadhav',
    message: 'Hello',
    dateTime: new Date().toString(),
  },
  {
    senderId: 55,
    senderName: 'Dhiren Yadav',
    message: 'Hello',
    dateTime: new Date().toString(),
  },
  {
    senderId: 63,
    senderName: 'Santosh Kumar',
    message: 'Hello',
    dateTime: new Date().toString(),
  },
];
