import { Injectable } from "@angular/core";
import { DUMMY_CHAT_DATA, IMessage } from "./typings";

@Injectable()
export class ChatService {
    private messages: IMessage[] = DUMMY_CHAT_DATA;
    
    constructor(){}

    sendMessage(message: IMessage): void {
        this.messages.push(message);
    }

    getMessages(): IMessage[] {
        return this.messages;
    }
}