import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { EMAIL_REGEX_PATTERN } from '../shared/constants';
import { customFileValidator } from '../shared/custom-validators';
import { UserService } from '../shared/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.scss'],
})
export class UserRegistrationComponent implements OnInit {
  formGroup!: FormGroup;
  isSubmitted: boolean = false;

  constructor(private userService: UserService, private router: Router) {}

  ngOnInit(): void {
    this.setupUserRegistrationForm();
  }

  setupUserRegistrationForm(): void {
    this.formGroup = new FormGroup({
      name: new FormControl('', Validators.required),
      email: new FormControl('', [
        Validators.required,
        Validators.pattern(EMAIL_REGEX_PATTERN),
      ]),
      phoneNumber: new FormControl('', Validators.required),
      profilePhoto: new FormControl('', [
        Validators.required,
        customFileValidator,
      ]),
    });
  }

  onSubmitUserDetails({ valid, value }: FormGroup): void {
    if (valid) {
      console.log(value);
      this.userService.addUser(value);
      this.router.navigate(['user-list']);
    }
  }

  getControl(controlName: string): FormControl {
    return this.formGroup.get(controlName.toString()) as FormControl;
  }

  isRequired(controlName: string): boolean {
    return (
      (this.getControl(controlName).touched || this.isSubmitted) &&
      (this.getControl(controlName)?.errors?.required ||
        !this.getControl(controlName)?.value?.toString().trim())
    );
  }

  isInvalid(controlName: string): boolean {
    return (
      this.getControl(controlName)?.errors?.pattern &&
      this.getControl(controlName).value
    );
  }

  onFileSelected(event: any): void {
    this.formGroup.get('profilePhoto')?.setValue(event.target.files[0]);
    this.formGroup.get('profilePhoto')?.updateValueAndValidity();
  }

  isInvalidFile(controlName: string): boolean {
    return (
      !!this.getControl(controlName).value &&
      this.getControl(controlName)?.errors?.isInvalidFile
    );
  }
}
