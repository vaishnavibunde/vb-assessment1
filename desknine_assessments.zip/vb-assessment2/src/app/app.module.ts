import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { UserListComponent } from './user-list/user-list.component';
import {
  FormsModule,
  NG_VALIDATORS,
  ReactiveFormsModule,
} from '@angular/forms';
import { customFileValidator } from './shared/custom-validators';
import { UserService } from './shared/user.service';

@NgModule({
  declarations: [AppComponent, UserRegistrationComponent, UserListComponent],
  imports: [BrowserModule, AppRoutingModule, FormsModule, ReactiveFormsModule],
  providers: [
    { provide: NG_VALIDATORS, useValue: customFileValidator, multi: true },
    UserService,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
