export interface IUser {
  name: string;
  email: string;
  phoneNumber: number;
  profilePhoto: File | null;
}

export const DUMMY_USERS: IUser[] = [
    {
        name: 'Ganesh',
        email: 'g@gmail.com',
        phoneNumber: 898989899,
        profilePhoto: null
    },
    {
        name: 'Kathik',
        email: 'kg@gmail.com',
        phoneNumber: 56565656,
        profilePhoto: null
    },
    {
        name: 'Mayur',
        email: 'mayur@gmail.com',
        phoneNumber: 717787878,
        profilePhoto: null
    }
]