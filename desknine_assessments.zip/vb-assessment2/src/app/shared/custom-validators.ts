import { AbstractControl, ValidationErrors } from '@angular/forms';

export function customFileValidator(
  control: AbstractControl
): ValidationErrors | null {
  let isInvalidFile = false;

  if (
    control.value &&
    (Math.round(control.value.size / 1024) >= 1024 ||
      Math.round(control.value.size /1024) <= 500 ||
      (control.value.type !== 'image/png' &&
      control.value.type !== 'image/jpeg'))
  ) {
    isInvalidFile = true;
  }

  return isInvalidFile ? { isInvalidFile } : null;
}
