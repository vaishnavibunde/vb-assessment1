import { Injectable } from '@angular/core';
import { DUMMY_USERS, IUser } from './typings';

@Injectable()
export class UserService {
  constructor() {}
  private users: IUser[] = DUMMY_USERS;

  addUser(user: IUser): void {
    this.users.push(user);
  }

  getUsers(): IUser[] {
    return this.users;
  }
}
